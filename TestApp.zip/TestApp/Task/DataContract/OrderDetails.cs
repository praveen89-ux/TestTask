﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataContract
{
    public class OrderDetails
    {
        public Order order { get; set; }
        public string note { get; set; }
        public int qty { get; set; }
        public double price { get; set; }
        public double tax { get; set; }
        public double exclAmount { get; set; }
        public double taxAmount { get; set; }
        public double incAmount { get; set; }
    }
}
