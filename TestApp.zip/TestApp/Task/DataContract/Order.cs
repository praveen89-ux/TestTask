﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataContract
{
    public class Order
    {
        public Customer customert { get; set; }
        public string itemCode { get; set; }
        public string note { get; set; }
        public int invoiceNo { get; set; }
        public string invoiceDate { get; set; }
        public int refNo { get; set; }
    }
}
