﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataContract;
using DataAccessLayer;
using System.Data;

namespace BusinessLogicLayer
{
    public class Bll
    {
        Dal sDAL = null;


        public DataTable GetCustomerName()
        {
            DataTable dtCustomer = null;
            DataRow dr;
            try
            {
                sDAL = new Dal();
                dtCustomer = sDAL.GetCustomerName();
                
                    dr = dtCustomer.NewRow();
                    dr.ItemArray = new object[] { 0, "--Select--" };
                    dtCustomer.Rows.InsertAt(dr, 0);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtCustomer;
        }

        public Customer GetCustomerDetails(int cudtomerId)
        {
            DataTable dtCustomer = null;
            Customer objCustomer;
            try
            {
                sDAL = new Dal();
                objCustomer = new Customer();

                dtCustomer = sDAL.GetCustomerDetails(cudtomerId);

                if (dtCustomer != null && dtCustomer.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtCustomer.Rows)
                    {
                        objCustomer.address1 = dr["Address1"].ToString();
                        objCustomer.address2 = dr["Address2"].ToString();
                        objCustomer.address3 = dr["Address3"].ToString();
                        objCustomer.suburb = dr["Suburb"].ToString();
                        objCustomer.state = dr["State"].ToString();
                        objCustomer.postCode = dr["PostCode"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objCustomer;
        }

        public DataTable GetItemCodeList()
        {
            DataTable dtItemCode = null;
            DataRow dr;
            try
            {
                sDAL = new Dal();
                dtItemCode = sDAL.GetItemCodeList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtItemCode;
        }

        public DataTable GetItemDescriptionList()
        {
            DataTable dtItemDescription = null;
            DataRow dr;
            try
            {
                sDAL = new Dal();
                dtItemDescription = sDAL.GetItemDescriptionList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtItemDescription;
        }

        //public void  SaveOrder(Order objOrder, OrderDetails objOrderDetails)
        //{
        //    try
        //    {
        //        sDAL = new Dal();
        //        sDAL.SaveOrder(objOrder, objOrderDetails);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}
    }
}
