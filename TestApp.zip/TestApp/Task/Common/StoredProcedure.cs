﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class StoredProcedure
    {
        public enum Schemas
        {
            DBO
        }


        public enum Name
        {
            Customer_List,
            CustomerDetails_byCustomerId,
            ItemCode_List,
            ItemDescription_List
        }
    }
}
