﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class StringConstant
    {
        public const string SP_Module_Seperator = ".";
    }
}
