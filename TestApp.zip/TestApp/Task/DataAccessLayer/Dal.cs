﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using System.Data;
using System.Data.SqlClient;
using DataContract;

namespace DataAccessLayer
{
    public class Dal
    {
        #region Private Members

        private string connectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
        
        #endregion

        public DataTable GetCustomerName()
        {
            DataSet dsCustomer = null;
            SqlConnection conn = null;
            try
            {
                using (conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandText = StoredProcedure.Schemas.DBO + StringConstant.SP_Module_Seperator + StoredProcedure.Name.Customer_List.ToString();
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adp = new SqlDataAdapter();
                    adp.SelectCommand = cmd;
                    conn.Open();
                    dsCustomer = new DataSet();
                    adp.Fill(dsCustomer, "dsCustomer");
                    conn.Close();
                }

                return (dsCustomer.Tables.Count > 0) ? dsCustomer.Tables[0] : null;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }

        public DataTable GetCustomerDetails(int cudtomerId)
        {
            DataSet dsCustomer = null;
            SqlConnection conn = null;
            try
            {
                using (conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandText = StoredProcedure.Schemas.DBO + StringConstant.SP_Module_Seperator + StoredProcedure.Name.CustomerDetails_byCustomerId.ToString();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@customerId", cudtomerId);

                    SqlDataAdapter adp = new SqlDataAdapter();
                    adp.SelectCommand = cmd;
                    conn.Open();
                    dsCustomer = new DataSet();
                    adp.Fill(dsCustomer, "dsCustomer");
                    conn.Close();
                }

                return (dsCustomer.Tables.Count > 0) ? dsCustomer.Tables[0] : null;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }

        public DataTable GetItemCodeList()
        {
            DataSet dsItemCode = null;
            SqlConnection conn = null;
            try
            {
                using (conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandText = StoredProcedure.Schemas.DBO + StringConstant.SP_Module_Seperator + StoredProcedure.Name.ItemCode_List.ToString();
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adp = new SqlDataAdapter();
                    adp.SelectCommand = cmd;
                    conn.Open();
                    dsItemCode = new DataSet();
                    adp.Fill(dsItemCode, "dsItemCode");
                    conn.Close();
                }

                return (dsItemCode.Tables.Count > 0) ? dsItemCode.Tables[0] : null;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }

        public DataTable GetItemDescriptionList()
        {
            DataSet dsItemDescription = null;
            SqlConnection conn = null;
            try
            {
                using (conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandText = StoredProcedure.Schemas.DBO + StringConstant.SP_Module_Seperator + StoredProcedure.Name.ItemDescription_List.ToString();
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adp = new SqlDataAdapter();
                    adp.SelectCommand = cmd;
                    conn.Open();
                    dsItemDescription = new DataSet();
                    adp.Fill(dsItemDescription, "dsItemDescription");
                    conn.Close();
                }

                return (dsItemDescription.Tables.Count > 0) ? dsItemDescription.Tables[0] : null;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
    }
}
