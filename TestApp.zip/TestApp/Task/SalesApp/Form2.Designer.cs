﻿namespace SalesApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dgvItem = new System.Windows.Forms.DataGridView();
            this.cmbItemCode = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.cmbDescription = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.txtGDVNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtTax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtExclAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtTaxAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtIncAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cbmCustomerName = new System.Windows.Forms.ComboBox();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress3 = new System.Windows.Forms.TextBox();
            this.txtSuburb = new System.Windows.Forms.TextBox();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtPostCode = new System.Windows.Forms.TextBox();
            this.txtInvoiceNo = new System.Windows.Forms.TextBox();
            this.txtInvoiceDate = new System.Windows.Forms.TextBox();
            this.txtRefNo = new System.Windows.Forms.TextBox();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtTotExcl = new System.Windows.Forms.TextBox();
            this.txtTotTax = new System.Windows.Forms.TextBox();
            this.txtTotIncl = new System.Windows.Forms.TextBox();
            this.btnSaveOrder = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItem)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Address1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Address2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Address3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 156);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Suburb";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "State";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 208);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Post Code";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(349, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Invoice No";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(349, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Invoice Date";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(349, 112);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Reference No";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(349, 137);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Note";
            // 
            // dgvItem
            // 
            this.dgvItem.AllowUserToOrderColumns = true;
            this.dgvItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvItem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cmbItemCode,
            this.cmbDescription,
            this.txtGDVNote,
            this.txtQuantity,
            this.txtPrice,
            this.txtTax,
            this.txtExclAmount,
            this.txtTaxAmount,
            this.txtIncAmount});
            this.dgvItem.Location = new System.Drawing.Point(15, 238);
            this.dgvItem.Name = "dgvItem";
            this.dgvItem.Size = new System.Drawing.Size(733, 143);
            this.dgvItem.TabIndex = 1;
            this.dgvItem.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItem_CellEndEdit);
            // 
            // cmbItemCode
            // 
            this.cmbItemCode.HeaderText = "Item Code";
            this.cmbItemCode.Name = "cmbItemCode";
            this.cmbItemCode.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cmbItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // cmbDescription
            // 
            this.cmbDescription.HeaderText = "Description";
            this.cmbDescription.Name = "cmbDescription";
            this.cmbDescription.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cmbDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.cmbDescription.Width = 130;
            // 
            // txtGDVNote
            // 
            this.txtGDVNote.HeaderText = "Note";
            this.txtGDVNote.Name = "txtGDVNote";
            this.txtGDVNote.Width = 50;
            // 
            // txtQuantity
            // 
            this.txtQuantity.HeaderText = "Quantity";
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Width = 50;
            // 
            // txtPrice
            // 
            this.txtPrice.HeaderText = "Price";
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Width = 60;
            // 
            // txtTax
            // 
            this.txtTax.HeaderText = "Tax";
            this.txtTax.Name = "txtTax";
            this.txtTax.Width = 60;
            // 
            // txtExclAmount
            // 
            this.txtExclAmount.HeaderText = "Excl Amount";
            this.txtExclAmount.Name = "txtExclAmount";
            this.txtExclAmount.ReadOnly = true;
            this.txtExclAmount.Width = 80;
            // 
            // txtTaxAmount
            // 
            this.txtTaxAmount.HeaderText = "Tax Amount";
            this.txtTaxAmount.Name = "txtTaxAmount";
            this.txtTaxAmount.ReadOnly = true;
            this.txtTaxAmount.Width = 80;
            // 
            // txtIncAmount
            // 
            this.txtIncAmount.HeaderText = "Inc Amount";
            this.txtIncAmount.Name = "txtIncAmount";
            this.txtIncAmount.ReadOnly = true;
            this.txtIncAmount.Width = 80;
            // 
            // cbmCustomerName
            // 
            this.cbmCustomerName.FormattingEnabled = true;
            this.cbmCustomerName.Location = new System.Drawing.Point(100, 42);
            this.cbmCustomerName.Name = "cbmCustomerName";
            this.cbmCustomerName.Size = new System.Drawing.Size(121, 21);
            this.cbmCustomerName.TabIndex = 2;
            this.cbmCustomerName.SelectedIndexChanged += new System.EventHandler(this.cbmCustomerName_SelectedIndexChanged);
            // 
            // txtAddress1
            // 
            this.txtAddress1.Location = new System.Drawing.Point(100, 75);
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(100, 20);
            this.txtAddress1.TabIndex = 3;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Location = new System.Drawing.Point(100, 100);
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(100, 20);
            this.txtAddress2.TabIndex = 3;
            // 
            // txtAddress3
            // 
            this.txtAddress3.Location = new System.Drawing.Point(100, 124);
            this.txtAddress3.Name = "txtAddress3";
            this.txtAddress3.Size = new System.Drawing.Size(100, 20);
            this.txtAddress3.TabIndex = 3;
            // 
            // txtSuburb
            // 
            this.txtSuburb.Location = new System.Drawing.Point(100, 149);
            this.txtSuburb.Name = "txtSuburb";
            this.txtSuburb.Size = new System.Drawing.Size(100, 20);
            this.txtSuburb.TabIndex = 3;
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(100, 180);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(100, 20);
            this.txtState.TabIndex = 3;
            // 
            // txtPostCode
            // 
            this.txtPostCode.Location = new System.Drawing.Point(100, 205);
            this.txtPostCode.Name = "txtPostCode";
            this.txtPostCode.Size = new System.Drawing.Size(100, 20);
            this.txtPostCode.TabIndex = 3;
            // 
            // txtInvoiceNo
            // 
            this.txtInvoiceNo.Location = new System.Drawing.Point(434, 42);
            this.txtInvoiceNo.Name = "txtInvoiceNo";
            this.txtInvoiceNo.Size = new System.Drawing.Size(100, 20);
            this.txtInvoiceNo.TabIndex = 3;
            // 
            // txtInvoiceDate
            // 
            this.txtInvoiceDate.Location = new System.Drawing.Point(434, 72);
            this.txtInvoiceDate.Name = "txtInvoiceDate";
            this.txtInvoiceDate.Size = new System.Drawing.Size(100, 20);
            this.txtInvoiceDate.TabIndex = 3;
            // 
            // txtRefNo
            // 
            this.txtRefNo.Location = new System.Drawing.Point(434, 105);
            this.txtRefNo.Name = "txtRefNo";
            this.txtRefNo.Size = new System.Drawing.Size(100, 20);
            this.txtRefNo.TabIndex = 3;
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(434, 134);
            this.txtNote.Multiline = true;
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(155, 79);
            this.txtNote.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(460, 399);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Total Excl";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(460, 426);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Total Tax";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(460, 455);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "Total Incl";
            // 
            // txtTotExcl
            // 
            this.txtTotExcl.Location = new System.Drawing.Point(540, 396);
            this.txtTotExcl.Name = "txtTotExcl";
            this.txtTotExcl.Size = new System.Drawing.Size(100, 20);
            this.txtTotExcl.TabIndex = 3;
            this.txtTotExcl.Text = "0";
            // 
            // txtTotTax
            // 
            this.txtTotTax.Location = new System.Drawing.Point(540, 423);
            this.txtTotTax.Name = "txtTotTax";
            this.txtTotTax.Size = new System.Drawing.Size(100, 20);
            this.txtTotTax.TabIndex = 3;
            this.txtTotTax.Text = "0";
            // 
            // txtTotIncl
            // 
            this.txtTotIncl.Location = new System.Drawing.Point(540, 452);
            this.txtTotIncl.Name = "txtTotIncl";
            this.txtTotIncl.Size = new System.Drawing.Size(100, 20);
            this.txtTotIncl.TabIndex = 3;
            this.txtTotIncl.Text = "0";
            // 
            // btnSaveOrder
            // 
            this.btnSaveOrder.Location = new System.Drawing.Point(15, 12);
            this.btnSaveOrder.Name = "btnSaveOrder";
            this.btnSaveOrder.Size = new System.Drawing.Size(75, 23);
            this.btnSaveOrder.TabIndex = 4;
            this.btnSaveOrder.Text = "Save Order";
            this.btnSaveOrder.UseVisualStyleBackColor = true;
            this.btnSaveOrder.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 481);
            this.Controls.Add(this.btnSaveOrder);
            this.Controls.Add(this.txtPostCode);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.txtSuburb);
            this.Controls.Add(this.txtAddress3);
            this.Controls.Add(this.txtAddress2);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.txtTotIncl);
            this.Controls.Add(this.txtTotTax);
            this.Controls.Add(this.txtTotExcl);
            this.Controls.Add(this.txtRefNo);
            this.Controls.Add(this.txtInvoiceDate);
            this.Controls.Add(this.txtInvoiceNo);
            this.Controls.Add(this.txtAddress1);
            this.Controls.Add(this.cbmCustomerName);
            this.Controls.Add(this.dgvItem);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Sales Order";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvItem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dgvItem;
        private System.Windows.Forms.ComboBox cbmCustomerName;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress3;
        private System.Windows.Forms.TextBox txtSuburb;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.TextBox txtPostCode;
        private System.Windows.Forms.TextBox txtInvoiceNo;
        private System.Windows.Forms.TextBox txtInvoiceDate;
        private System.Windows.Forms.TextBox txtRefNo;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.DataGridViewComboBoxColumn cmbItemCode;
        private System.Windows.Forms.DataGridViewComboBoxColumn cmbDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtGDVNote;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtTax;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtExclAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtTaxAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtIncAmount;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTotExcl;
        private System.Windows.Forms.TextBox txtTotTax;
        private System.Windows.Forms.TextBox txtTotIncl;
        private System.Windows.Forms.Button btnSaveOrder;
    }
}