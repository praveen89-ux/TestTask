﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataContract;
using BusinessLogicLayer;

namespace SalesApp
{
    public partial class Form2 : Form
    {
        Bll bll = null;
        Customer objCustomer;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            GetCustomerName();
        }

        private void cbmCustomerName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbmCustomerName.SelectedIndex > 0)
            {
                GetCustomerDetails();
                GetItemCodeList();
                GetItemDescriptionList();
            }

        }

        private void GetCustomerDetails()
        {
            bll = new Bll();
            objCustomer = new Customer();
            try
            {
                int customerId = Convert.ToInt32(cbmCustomerName.SelectedValue.ToString());

                objCustomer = bll.GetCustomerDetails(customerId);
                txtAddress1.Text = objCustomer.address1;
                txtAddress2.Text = objCustomer.address2;
                txtAddress3.Text = objCustomer.address3;
                txtSuburb.Text = objCustomer.suburb;
                txtState.Text = objCustomer.state;
                txtPostCode.Text = objCustomer.postCode;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void GetCustomerName()
        {
            bll = new Bll();
            cbmCustomerName.DataSource = bll.GetCustomerName();
            cbmCustomerName.ValueMember = "Id";
            cbmCustomerName.DisplayMember = "Name";
        }
        private void GetItemCodeList()
        {
            bll = new Bll();
            cmbItemCode.DataSource = bll.GetItemCodeList();
            cmbItemCode.ValueMember = "Id";
            cmbItemCode.DisplayMember = "Name";
            
        }
        private void GetItemDescriptionList()
        {
            bll = new Bll();
            cmbDescription.DataSource = bll.GetItemDescriptionList();
            cmbDescription.ValueMember = "Id";
            cmbDescription.DisplayMember = "Name";
        }

        private void dgvItem_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 )
            {
                int qut = 0,tax = 0;
                double price = 0, eA = 0, tA = 0, iA = 0, totExc = 0, totTax = 0, totInc = 0;
                DataGridViewRow row = dgvItem.Rows[e.RowIndex];

                if (e.ColumnIndex == 4)
                {
                    qut = Convert.ToInt32(row.Cells[3].Value.ToString());
                    price = Convert.ToDouble(row.Cells[4].Value.ToString());

                    eA = qut * price;
                    row.Cells[6].Value = eA;

                    totExc = Convert.ToDouble(txtTotExcl.Text);
                    totExc = totExc + eA;
                    txtTotExcl.Text = totExc.ToString();
                }
                if (e.ColumnIndex == 5)
                {
                    tax = Convert.ToInt32(row.Cells[5].Value.ToString());
                    eA = Convert.ToDouble(row.Cells[6].Value.ToString());

                    tA = eA * tax / 100;
                    row.Cells[7].Value = tA;

                    totTax = Convert.ToDouble(txtTotTax.Text);
                    totTax = totTax + tA;
                    txtTotTax.Text = totTax.ToString();

                    iA = eA + tA;
                    row.Cells[8].Value = iA;

                    totInc = Convert.ToDouble(txtTotIncl.Text);
                    totInc = totInc + iA;
                    txtTotIncl.Text = totInc.ToString();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveOrder();
        }

        private void SaveOrder()
        {
            bll = new Bll();
            Order objOrder = new Order();
            OrderDetails objOrderDetails = new OrderDetails();

            objOrder.customert.id = Convert.ToInt32(cbmCustomerName.SelectedText.ToString());
            objOrder.note = txtNote.Text;
            objOrder.invoiceNo = Convert.ToInt32(txtInvoiceNo.Text);
            objOrder.invoiceDate = txtInvoiceDate.Text;
            objOrder.refNo = Convert.ToInt32(txtRefNo.Text);
            objOrderDetails.order.invoiceNo = Convert.ToInt32(txtInvoiceNo.Text);

            for(int i = 0; i < dgvItem.RowCount; i++)
            {
                DataGridViewRow row = dgvItem.Rows[0];

                objOrder.itemCode = row.Cells[0].Value.ToString();
                objOrderDetails.note = row.Cells[2].Value.ToString();
                objOrderDetails.qty = Convert.ToInt32(row.Cells[3].Value.ToString());
                objOrderDetails.price = Convert.ToDouble(row.Cells[4].Value.ToString());
                objOrderDetails.tax = Convert.ToDouble(row.Cells[5].Value.ToString());
                objOrderDetails.exclAmount = Convert.ToDouble(row.Cells[6].Value.ToString());
                objOrderDetails.taxAmount = Convert.ToDouble(row.Cells[7].Value.ToString());
                objOrderDetails.incAmount = Convert.ToDouble(row.Cells[8].Value.ToString());

                
            }
        }
    }
}
